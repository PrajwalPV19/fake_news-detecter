import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AnalysisInput } from './components/AnalysisInput';
import { AnalysisResultView } from './components/AnalysisResult';
import { LandingPage } from './components/LandingPage';
import { AuthForms } from './components/AuthForms';
import { analyzeTextWithGemini } from './services/geminiService';
import { authService } from './services/authService';
import { AnalysisResult, AnalysisStatus, AppView, User } from './types';
import { AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  // Navigation & User State
  const [currentView, setCurrentView] = useState<AppView>('LANDING');
  const [user, setUser] = useState<User | null>(null);

  // Analysis State
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Initialize Session
  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setCurrentView('DETECTOR');
    }
  }, []);

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
    // Reset analysis state when leaving detector
    if (view !== 'DETECTOR') {
      setStatus(AnalysisStatus.IDLE);
      setResult(null);
    }
  };

  const handleLoginSuccess = (user: User) => {
    setUser(user);
    setCurrentView('DETECTOR');
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
    setResult(null);
    setStatus(AnalysisStatus.IDLE);
    setCurrentView('LANDING');
  };

  const handleAnalyze = async (text: string) => {
    setStatus(AnalysisStatus.ANALYZING);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeTextWithGemini(text);
      setResult(data);
      setStatus(AnalysisStatus.COMPLETE);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setStatus(AnalysisStatus.ERROR);
    }
  };

  // Render Logic
  const renderContent = () => {
    switch (currentView) {
      case 'LANDING':
        return <LandingPage onNavigate={handleNavigate} />;
      
      case 'LOGIN':
        return <AuthForms view="LOGIN" onNavigate={handleNavigate} onSuccess={handleLoginSuccess} />;
      
      case 'REGISTER':
        return <AuthForms view="REGISTER" onNavigate={handleNavigate} onSuccess={handleLoginSuccess} />;
      
      case 'DETECTOR':
        return (
          <div className="w-full flex flex-col items-center animate-fade-up">
            {status === AnalysisStatus.IDLE && (
               <AnalysisInput onAnalyze={handleAnalyze} isLoading={false} />
            )}

            {status === AnalysisStatus.ANALYZING && (
               <div className="w-full max-w-2xl text-center py-20 glass-panel rounded-3xl p-8">
                  <div className="relative w-24 h-24 mx-auto mb-8">
                    <div className="absolute inset-0 border-4 border-ink-100 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-ink-800 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-ink-900 mb-2">Analyzing Information</h3>
                  <p className="text-ink-500 animate-pulse">Cross-referencing global sources to separate fact from fiction...</p>
               </div>
            )}

            {status === AnalysisStatus.ERROR && (
              <div className="w-full max-w-lg text-center mt-10 animate-fade-up">
                 <div className="bg-red-50/90 p-8 rounded-2xl border border-red-100 flex flex-col items-center shadow-lg backdrop-blur-sm">
                    <AlertCircle className="w-12 h-12 text-myth-DEFAULT mb-4" />
                    <h3 className="text-xl font-bold text-ink-900 mb-2">Analysis Failed</h3>
                    <p className="text-ink-600 mb-6">{error}</p>
                    <button 
                      onClick={() => setStatus(AnalysisStatus.IDLE)}
                      className="px-8 py-3 bg-white border border-red-200 text-myth-dark font-medium rounded-xl hover:bg-red-50 transition-colors shadow-sm"
                    >
                      Try Again
                    </button>
                 </div>
              </div>
            )}

            {status === AnalysisStatus.COMPLETE && result && (
              <div className="w-full flex flex-col items-center">
                 <AnalysisResultView result={result} />
                 
                 <button
                   onClick={() => {
                     setStatus(AnalysisStatus.IDLE);
                     setResult(null);
                   }}
                   className="fixed bottom-8 right-8 z-40 bg-ink-950 text-white px-8 py-4 rounded-full font-medium shadow-2xl hover:bg-black transition-all hover:scale-105 flex items-center gap-3 border border-ink-800"
                 >
                   Analyze Another
                 </button>
              </div>
            )}
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans relative">
      {/* Background Elements */}
      <div className="bg-noise z-[1]"></div>
      
      {/* Dynamic Color Blobs - Truth vs Myth Theme */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {/* The "Truth" Blue/Teal Blob */}
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-blue-200/30 rounded-full mix-blend-multiply filter blur-[80px] animate-blob"></div>
        
        {/* The "Myth" Red/Pink Blob */}
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-myth-light/30 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-2000"></div>
        
        {/* The "Neutral" Center Blob */}
        <div className="absolute top-[30%] left-[30%] w-[40vw] h-[40vw] bg-indigo-100/30 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        <Header 
          user={user} 
          currentView={currentView}
          onNavigate={handleNavigate} 
          onLogout={handleLogout} 
        />
        
        <main className="flex-grow flex flex-col items-center w-full px-4 pt-8 md:pt-12 pb-12">
          {renderContent()}
        </main>

        <footer className="py-8 text-center text-ink-400 text-sm w-full relative z-10">
          <p className="opacity-70">© {new Date().getFullYear()} FakeNDetecter. Truth in the age of digital chaos.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;