import React, { useState } from 'react';
import { Sparkles, X, Quote } from 'lucide-react';

interface AnalysisInputProps {
  onAnalyze: (text: string) => void;
  isLoading: boolean;
}

export const AnalysisInput: React.FC<AnalysisInputProps> = ({ onAnalyze, isLoading }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isLoading) {
      onAnalyze(text);
    }
  };

  const handleClear = () => setText('');

  return (
    <div className="w-full max-w-4xl mx-auto mb-12 px-4 animate-fade-up">
      <div className="text-center mb-10">
        <h2 className="text-4xl md:text-5xl font-serif text-ink-950 mb-4">
          Verify the Narrative
        </h2>
        <p className="text-ink-500 text-lg font-light">
          Paste the claim, headline, or article text below.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-ink-200 to-ink-100 rounded-[2rem] opacity-50 blur-xl group-hover:opacity-75 transition duration-1000"></div>
        
        <div className="relative bg-white/80 backdrop-blur-xl rounded-[2rem] shadow-xl border border-white/60 overflow-hidden">
          <div className="absolute top-6 left-6 text-ink-200 pointer-events-none">
            <Quote size={40} />
          </div>
          
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="e.g., 'New study claims chocolate cures all diseases...'"
            className="w-full h-56 p-8 pl-12 text-xl md:text-2xl font-serif text-ink-900 placeholder:text-ink-300 bg-transparent resize-none focus:outline-none focus:ring-0 leading-relaxed"
            disabled={isLoading}
          />
          
          <div className="px-6 py-4 border-t border-ink-50 bg-white/40 flex justify-between items-center backdrop-blur-sm">
            <button
              type="button"
              onClick={handleClear}
              disabled={!text || isLoading}
              className="text-sm font-medium text-ink-400 hover:text-ink-600 disabled:opacity-0 transition-all flex items-center gap-2"
            >
              <X size={16} /> Clear Text
            </button>

            <button
              type="submit"
              disabled={!text.trim() || isLoading}
              className={`
                flex items-center gap-3 px-8 py-3 rounded-xl font-medium text-white transition-all duration-500
                ${!text.trim() || isLoading 
                  ? 'bg-ink-200 cursor-not-allowed text-ink-400' 
                  : 'bg-ink-950 hover:bg-black hover:shadow-lg hover:scale-[1.02]'}
              `}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing
                </>
              ) : (
                <>
                  <Sparkles size={18} />
                  Run Analysis
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Minimalist Suggestions */}
      {!text && (
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button 
            onClick={() => setText("The government just passed a law banning all gas cars by 2025.")}
            className="text-sm bg-white/60 border border-white text-ink-500 px-4 py-2 rounded-full hover:bg-white hover:text-ink-800 transition-all shadow-sm backdrop-blur-sm"
          >
            Example: Policy Ban
          </button>
          <button 
             onClick={() => setText("Scientists discover a new planet made entirely of diamond.")}
             className="text-sm bg-white/60 border border-white text-ink-500 px-4 py-2 rounded-full hover:bg-white hover:text-ink-800 transition-all shadow-sm backdrop-blur-sm"
          >
            Example: Science News
          </button>
        </div>
      )}
    </div>
  );
};