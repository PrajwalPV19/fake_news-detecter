import React from 'react';
import { ShieldCheck, LogOut, User as UserIcon } from 'lucide-react';
import { User, AppView } from '../types';

interface HeaderProps {
  user: User | null;
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, currentView, onNavigate, onLogout }) => {
  return (
    <header className="w-full border-b border-white/20 bg-white/60 backdrop-blur-xl sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        
        {/* Logo Section */}
        <div 
          className="flex items-center gap-3 group cursor-pointer"
          onClick={() => onNavigate(user ? 'DETECTOR' : 'LANDING')}
        >
          <div className="bg-ink-950 p-2 rounded-lg text-white transition-transform group-hover:scale-105 duration-300 shadow-lg shadow-ink-500/10">
             <ShieldCheck size={22} strokeWidth={2} />
          </div>
          <div className="flex flex-col">
            <h1 className="font-serif text-xl font-bold text-ink-950 tracking-tight leading-none">FakeNDetecter</h1>
            <span className="text-[10px] uppercase tracking-[0.2em] text-ink-500 font-medium mt-0.5">Truth Engine</span>
          </div>
        </div>

        {/* Navigation / Auth Section */}
        <nav className="flex items-center gap-6">
          {user ? (
            <div className="flex items-center gap-4">
              <span className="hidden md:flex items-center gap-2 text-sm font-medium text-ink-600 bg-ink-50/50 border border-ink-100 px-4 py-2 rounded-full backdrop-blur-sm">
                <UserIcon size={14} className="text-ink-400"/>
                {user.name}
              </span>
              <button 
                onClick={onLogout}
                className="text-sm font-medium text-ink-500 hover:text-myth-DEFAULT transition-colors flex items-center gap-2 px-2"
              >
                <LogOut size={18} />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
               {currentView !== 'LOGIN' && (
                 <button 
                   onClick={() => onNavigate('LOGIN')}
                   className="text-sm font-medium text-ink-600 hover:text-ink-900 px-4 py-2 transition-colors"
                 >
                   Log in
                 </button>
               )}
               {currentView !== 'REGISTER' && (
                 <button 
                   onClick={() => onNavigate('REGISTER')}
                   className="text-sm font-medium bg-ink-950 text-white px-6 py-2.5 rounded-full hover:bg-black hover:shadow-xl hover:shadow-ink-900/10 transition-all active:scale-95"
                 >
                   Start Verifying
                 </button>
               )}
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};