import React from 'react';
import { Shield, Search, Globe, ArrowRight, Check, Activity } from 'lucide-react';
import { AppView } from '../types';

interface LandingPageProps {
  onNavigate: (view: AppView) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="w-full flex flex-col">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 lg:pt-32 lg:pb-40 text-center px-4">
        <div className="max-w-4xl mx-auto relative z-10 animate-fade-up">
          <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/50 border border-white/60 text-ink-600 text-xs font-bold tracking-widest backdrop-blur-md shadow-sm mb-10">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-truth-DEFAULT opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-truth-DEFAULT"></span>
            </span>
            SYSTEM OPERATIONAL
          </div>
          
          <h1 className="text-6xl md:text-8xl font-serif font-medium text-ink-950 mb-8 leading-[1] tracking-tight">
            Distinguish <br/>
            <span className="italic text-ink-500">Truth</span> from <span className="italic text-myth-DEFAULT">Myth</span>
          </h1>
          
          <p className="max-w-2xl mx-auto text-xl text-ink-600 mb-12 leading-relaxed font-light">
            In an era of digital noise, clarity is power. Our AI agent instantly verifies social media claims against global news sources.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => onNavigate('REGISTER')}
              className="w-full sm:w-auto px-10 py-5 bg-ink-950 text-white rounded-2xl font-medium text-lg hover:bg-black hover:scale-105 transition-all shadow-2xl shadow-ink-900/20 flex items-center justify-center gap-3 group"
            >
              Analyze Content
              <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
            </button>
            <button 
              onClick={() => onNavigate('LOGIN')}
              className="w-full sm:w-auto px-10 py-5 bg-white/40 text-ink-900 border border-white/50 rounded-2xl font-medium text-lg hover:bg-white/60 backdrop-blur-md transition-all"
            >
              Log in
            </button>
          </div>
        </div>
      </section>

      {/* Feature Grid - Glass Cards */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <GlassCard 
              icon={<Search className="text-ink-900" size={28} />}
              title="Deep Search"
              description="We don't just read. We scour the live web, cross-referencing claims against established reporting."
            />
            <GlassCard 
              icon={<Activity className="text-ink-900" size={28} />}
              title="Bias & Sentiment"
              description="Identify emotional manipulation, political leaning, and satirical tone in seconds."
            />
            <GlassCard 
              icon={<Globe className="text-ink-900" size={28} />}
              title="Global Context"
              description="Understand how a story is being reported across different regions and languages."
            />
          </div>
        </div>
      </section>

      {/* Stats / Trust Minimalist Strip */}
      <section className="py-20 border-t border-ink-100/50 bg-white/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-12 text-center md:text-left">
           <div>
             <h3 className="text-3xl font-serif text-ink-950 mb-2">The Standard for Verification</h3>
             <p className="text-ink-500">Built for journalists, researchers, and you.</p>
           </div>
           <div className="flex gap-12 opacity-80">
              <div className="flex flex-col items-center md:items-start">
                 <span className="text-4xl font-serif text-ink-900">98%</span>
                 <span className="text-xs uppercase tracking-widest text-ink-500 mt-1">Accuracy Rate</span>
              </div>
              <div className="flex flex-col items-center md:items-start">
                 <span className="text-4xl font-serif text-ink-900">0.2s</span>
                 <span className="text-xs uppercase tracking-widest text-ink-500 mt-1">Analysis Time</span>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};

const GlassCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="p-10 rounded-3xl glass-panel hover:bg-white/80 transition-all duration-500 group">
    <div className="mb-8 w-16 h-16 rounded-2xl bg-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform duration-500 border border-ink-50">
      {icon}
    </div>
    <h3 className="text-2xl font-serif text-ink-950 mb-4">{title}</h3>
    <p className="text-ink-600 leading-relaxed font-light text-lg">{description}</p>
  </div>
);