import React from 'react';
import { AnalysisResult } from '../types';
import { TrustGauge } from './TrustGauge';
import { CheckCircle2, AlertTriangle, AlertOctagon, Info, ExternalLink, HelpCircle, FileText } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AnalysisResultViewProps {
  result: AnalysisResult;
}

export const AnalysisResultView: React.FC<AnalysisResultViewProps> = ({ result }) => {
  
  const getVerdictStyles = (verdict: AnalysisResult['verdict']) => {
    switch (verdict) {
      case 'TRUE':
        return {
          icon: <CheckCircle2 className="w-6 h-6 text-truth-DEFAULT" />,
          colorClass: 'text-truth-dark',
          borderClass: 'border-truth-light',
          bgClass: 'bg-truth-light/20',
        };
      case 'FALSE':
        return {
          icon: <AlertOctagon className="w-6 h-6 text-myth-DEFAULT" />,
          colorClass: 'text-myth-dark',
          borderClass: 'border-myth-light',
          bgClass: 'bg-myth-light/20',
        };
      case 'MISLEADING':
        return {
          icon: <AlertTriangle className="w-6 h-6 text-orange-500" />,
          colorClass: 'text-orange-800',
          borderClass: 'border-orange-100',
          bgClass: 'bg-orange-50/50',
        };
      case 'SATIRE':
        return {
          icon: <Info className="w-6 h-6 text-blue-500" />,
          colorClass: 'text-blue-800',
          borderClass: 'border-blue-100',
          bgClass: 'bg-blue-50/50',
        };
      default:
        return {
          icon: <HelpCircle className="w-6 h-6 text-ink-500" />,
          colorClass: 'text-ink-800',
          borderClass: 'border-ink-100',
          bgClass: 'bg-ink-50/50',
        };
    }
  };

  const styles = getVerdictStyles(result.verdict);

  return (
    <div className="animate-fade-up w-full max-w-5xl mx-auto pb-20">
      
      {/* Top Section: Verdict & Score */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-8">
        
        {/* Verdict Panel */}
        <div className={`md:col-span-8 rounded-[2rem] glass-panel p-10 flex flex-col justify-between shadow-xl shadow-ink-900/5`}>
          <div>
             <div className="flex items-center gap-3 mb-6">
                <span className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase border ${styles.borderClass} ${styles.bgClass} ${styles.colorClass}`}>
                  {styles.icon}
                  Result
                </span>
                <span className="h-px flex-grow bg-ink-100"></span>
             </div>
             
             <h2 className={`text-6xl font-serif font-medium ${styles.colorClass} mb-4 tracking-tight`}>
                {result.verdict === 'TRUE' ? 'Verified True' : 
                 result.verdict === 'FALSE' ? 'False Information' : 
                 result.verdict.charAt(0) + result.verdict.slice(1).toLowerCase()}
             </h2>
             
             <p className="text-ink-600 text-xl font-light leading-relaxed max-w-2xl">
               Our investigation suggests this content is <strong className={`font-semibold ${styles.colorClass}`}>{result.verdict.toLowerCase()}</strong>. 
               Cross-referencing with trusted indices indicates {result.score > 60 ? 'strong factual alignment' : 'significant discrepancies'}.
             </p>
          </div>
        </div>

        {/* Score Panel */}
        <div className="md:col-span-4 bg-white/60 backdrop-blur-xl rounded-[2rem] border border-white/50 p-8 flex flex-col items-center justify-center shadow-lg">
          <TrustGauge score={result.score} />
          <div className="text-center mt-4">
            <h3 className="text-sm font-bold uppercase tracking-widest text-ink-400">Trust Score</h3>
            <p className="text-xs text-ink-400 mt-1">AI Confidence Index</p>
          </div>
        </div>
      </div>

      {/* Deep Dive Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main Analysis */}
        <div className="lg:col-span-8">
          <div className="bg-white/80 backdrop-blur-md rounded-[2rem] border border-white/60 shadow-lg p-10">
            <div className="flex items-center gap-3 mb-8 pb-4 border-b border-ink-100">
               <FileText className="text-ink-400" size={24} />
               <h3 className="text-xl font-serif font-bold text-ink-950">Detailed Briefing</h3>
            </div>
            
            <div className="prose prose-lg prose-slate max-w-none prose-headings:font-serif prose-headings:font-medium prose-p:text-ink-600 prose-p:font-light prose-p:leading-8 prose-strong:font-semibold prose-strong:text-ink-900 prose-a:text-blue-600 hover:prose-a:text-blue-700">
               <ReactMarkdown>{result.explanation}</ReactMarkdown>
            </div>
          </div>
        </div>

        {/* Sources Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white/40 backdrop-blur-md rounded-[2rem] border border-white/40 p-8 sticky top-24">
            <h3 className="text-xs font-bold text-ink-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-truth-DEFAULT animate-pulse"></span>
              Citations
            </h3>
            
            {result.sources.length > 0 ? (
              <ul className="space-y-4">
                {result.sources.map((source, idx) => (
                  <li key={idx}>
                    <a 
                      href={source.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="group block bg-white border border-ink-50 hover:border-ink-200 rounded-xl p-4 transition-all hover:shadow-md hover:-translate-y-0.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-base font-serif font-medium text-ink-900 line-clamp-2 group-hover:text-blue-700 transition-colors">
                          {source.title || "External Source"}
                        </span>
                        <ExternalLink size={14} className="text-ink-300 group-hover:text-blue-500 mt-1 flex-shrink-0" />
                      </div>
                      <div className="text-xs text-ink-400 mt-2 truncate font-mono">
                        {new URL(source.uri).hostname}
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-ink-400 text-sm italic p-4 bg-white/30 rounded-xl border border-dashed border-ink-200">
                No direct citations returned. The AI relied on general knowledge patterns.
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};