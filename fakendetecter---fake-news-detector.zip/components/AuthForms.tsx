import React, { useState } from 'react';
import { AppView } from '../types';
import { authService } from '../services/authService';
import { ArrowRight, Mail, Lock, User, Loader2 } from 'lucide-react';

interface AuthFormsProps {
  view: 'LOGIN' | 'REGISTER';
  onNavigate: (view: AppView) => void;
  onSuccess: (user: any) => void;
}

export const AuthForms: React.FC<AuthFormsProps> = ({ view, onNavigate, onSuccess }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      let user;
      if (view === 'LOGIN') {
        user = await authService.login(email, password);
      } else {
        if (!name) throw new Error("Name is required");
        user = await authService.register(name, email, password);
      }
      onSuccess(user);
    } catch (err: any) {
      setError(err.message || "Authentication failed");
    } finally {
      setIsLoading(false);
    }
  };

  const isLogin = view === 'LOGIN';

  return (
    <div className="w-full max-w-md mx-auto py-12 px-4 animate-fade-up">
      <div className="glass-panel rounded-[2rem] shadow-2xl shadow-ink-900/10 overflow-hidden relative">
        <div className="p-8 pb-6">
          <h2 className="text-3xl font-serif font-bold text-ink-950 mb-2">
            {isLogin ? 'Welcome Back' : 'Join the Network'}
          </h2>
          <p className="text-ink-500 font-light">
            {isLogin 
              ? 'Enter your credentials to access the detector.' 
              : 'Create an account to verify truth from fiction.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="px-8 pb-10 space-y-5">
          {error && (
            <div className="p-4 bg-red-50/80 border border-red-100 rounded-xl text-sm text-myth-dark">
              {error}
            </div>
          )}

          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-ink-400 uppercase tracking-widest ml-1">Full Name</label>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-400 group-focus-within:text-ink-600 transition-colors" size={18} />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 bg-white/50 border border-ink-100 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-ink-100 transition-all text-ink-800"
                  placeholder="John Doe"
                  required={!isLogin}
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-ink-400 uppercase tracking-widest ml-1">Email Address</label>
            <div className="relative group">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-400 group-focus-within:text-ink-600 transition-colors" size={18} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-white/50 border border-ink-100 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-ink-100 transition-all text-ink-800"
                placeholder="john@example.com"
                required
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-ink-400 uppercase tracking-widest ml-1">Password</label>
            <div className="relative group">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-400 group-focus-within:text-ink-600 transition-colors" size={18} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-white/50 border border-ink-100 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-ink-100 transition-all text-ink-800"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-ink-950 text-white rounded-xl font-bold hover:bg-black transition-all shadow-lg shadow-ink-900/20 flex items-center justify-center gap-2 mt-6 active:scale-[0.98]"
          >
            {isLoading ? (
              <Loader2 className="animate-spin" size={20} />
            ) : (
              <>
                {isLogin ? 'Sign In' : 'Create Account'}
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="bg-white/40 px-8 py-5 border-t border-ink-50 text-center backdrop-blur-sm">
          <p className="text-sm text-ink-500">
            {isLogin ? "New to verification?" : "Already verified?"}{' '}
            <button
              onClick={() => onNavigate(isLogin ? 'REGISTER' : 'LOGIN')}
              className="text-ink-900 font-bold hover:underline decoration-2 underline-offset-4"
            >
              {isLogin ? 'Create Account' : 'Log in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};