import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import * as d3 from 'd3';

interface TrustGaugeProps {
  score: number;
}

export const TrustGauge: React.FC<TrustGaugeProps> = ({ score }) => {
  // Data for the donut chart
  const data = [
    { name: 'Score', value: score },
    { name: 'Remaining', value: 100 - score },
  ];

  // Interpolate color from Red (0) to Yellow (50) to Green (100)
  const colorScale = d3.scaleLinear<string>()
    .domain([0, 50, 100])
    .range(['#ef4444', '#eab308', '#22c55e']);

  const scoreColor = colorScale(score);
  const emptyColor = '#f1f5f9'; // Slate-100

  return (
    <div className="relative h-64 w-64 mx-auto">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={80}
            outerRadius={100}
            startAngle={180}
            endAngle={0}
            paddingAngle={0}
            dataKey="value"
            stroke="none"
          >
            <Cell key="score" fill={scoreColor} cornerRadius={10} />
            <Cell key="remaining" fill={emptyColor} />
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      
      {/* Center Text */}
      <div className="absolute inset-0 top-1/2 left-0 right-0 -mt-10 flex flex-col items-center justify-center text-center pointer-events-none">
        <span className="text-5xl font-bold font-serif text-slate-800 tabular-nums">
          {score}
        </span>
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 mt-1">
          Trust Score
        </span>
      </div>
    </div>
  );
};
