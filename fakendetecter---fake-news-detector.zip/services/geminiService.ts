import { GoogleGenAI } from "@google/genai";
import { AnalysisResult, GroundingSource } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_PROMPT = `
You are FakeNDetecter, an expert investigative journalist and fact-checking engine. 
Your goal is to analyze text for factual accuracy, bias, and credibility.

You MUST follow this format for your response exactly:

LINE 1: VERDICT: [One of: TRUE, FALSE, MISLEADING, SATIRE, UNVERIFIED, MIXED] | SCORE: [Integer 0-100]
LINE 2: ---
LINE 3+: [Your detailed analysis in Markdown format. Be concise but thorough. Cite evidence.]

The Score represents the "Trust Score":
- 0-20: Total fabrication / Fake
- 21-40: Highly misleading / Propaganda
- 41-60: Mixed / Biased / Unverified
- 61-80: Mostly True / Needs Context
- 81-100: Verified / Highly Credible

Use Google Search to verify claims. If you find conflicting evidence, lower the score.
`;

export const analyzeTextWithGemini = async (text: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze this text for veracity:\n\n${text}`,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        tools: [{ googleSearch: {} }],
        temperature: 0.3, // Lower temperature for more analytical/deterministic output
      },
    });

    const rawText = response.text || "";
    
    // Extract Grounding Metadata
    const sources: GroundingSource[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
          sources.push({
            title: chunk.web.title || new URL(chunk.web.uri).hostname,
            uri: chunk.web.uri
          });
        }
      });
    }

    // Parse the structured header
    const lines = rawText.split('\n');
    const headerLine = lines[0];
    
    let verdict: AnalysisResult['verdict'] = 'UNVERIFIED';
    let score = 50;

    // Regex to extract Verdict and Score
    // Expected: VERDICT: TRUE | SCORE: 95
    const verdictMatch = headerLine.match(/VERDICT:\s*([A-Z]+)/i);
    const scoreMatch = headerLine.match(/SCORE:\s*(\d+)/);

    if (verdictMatch && verdictMatch[1]) {
      const v = verdictMatch[1].toUpperCase();
      if (['TRUE', 'FALSE', 'MISLEADING', 'SATIRE', 'UNVERIFIED', 'MIXED'].includes(v)) {
        verdict = v as AnalysisResult['verdict'];
      }
    }

    if (scoreMatch && scoreMatch[1]) {
      score = parseInt(scoreMatch[1], 10);
    }

    // Remove the header lines to get the clean markdown explanation
    // We look for the separator "---" or just slice after the first few lines if not found
    let explanation = rawText;
    const separatorIndex = lines.findIndex(line => line.trim() === '---');
    
    if (separatorIndex !== -1) {
      explanation = lines.slice(separatorIndex + 1).join('\n').trim();
    } else {
      // Fallback: if user didn't follow "---", try to strip the first line if it looks like the header
      if (headerLine.includes('VERDICT:')) {
         explanation = lines.slice(1).join('\n').trim();
      }
    }

    return {
      verdict,
      score,
      explanation,
      rawText,
      sources,
    };

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw new Error("Failed to analyze text. Please try again.");
  }
};