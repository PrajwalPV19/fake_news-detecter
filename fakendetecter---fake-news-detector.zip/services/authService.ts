import { User } from '../types';

const USERS_KEY = 'fakendetecter_users';
const SESSION_KEY = 'fakendetecter_session';

// Helper to simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const authService = {
  async register(name: string, email: string, password: string): Promise<User> {
    await delay(800); // Fake delay
    
    const usersStr = localStorage.getItem(USERS_KEY);
    const users: any[] = usersStr ? JSON.parse(usersStr) : [];
    
    if (users.find(u => u.email === email)) {
      throw new Error("Email already registered");
    }

    const newUser = {
      id: crypto.randomUUID(),
      name,
      email,
      password, // In a real app, verify this is never stored in plain text!
    };

    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    
    // Auto login
    const userSession: User = { id: newUser.id, name: newUser.name, email: newUser.email };
    localStorage.setItem(SESSION_KEY, JSON.stringify(userSession));
    
    return userSession;
  },

  async login(email: string, password: string): Promise<User> {
    await delay(800);
    
    const usersStr = localStorage.getItem(USERS_KEY);
    const users: any[] = usersStr ? JSON.parse(usersStr) : [];
    
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      throw new Error("Invalid email or password");
    }

    const userSession: User = { id: user.id, name: user.name, email: user.email };
    localStorage.setItem(SESSION_KEY, JSON.stringify(userSession));
    
    return userSession;
  },

  logout() {
    localStorage.removeItem(SESSION_KEY);
  },

  getCurrentUser(): User | null {
    const sessionStr = localStorage.getItem(SESSION_KEY);
    return sessionStr ? JSON.parse(sessionStr) : null;
  }
};