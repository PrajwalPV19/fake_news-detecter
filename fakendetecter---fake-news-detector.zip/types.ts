export interface GroundingSource {
  title?: string;
  uri: string;
}

export interface AnalysisResult {
  verdict: 'TRUE' | 'FALSE' | 'MISLEADING' | 'SATIRE' | 'UNVERIFIED' | 'MIXED';
  score: number;
  explanation: string;
  rawText: string;
  sources: GroundingSource[];
}

export enum AnalysisStatus {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR',
}

export interface User {
  id: string;
  name: string;
  email: string;
}

export type AppView = 'LANDING' | 'LOGIN' | 'REGISTER' | 'DETECTOR';
